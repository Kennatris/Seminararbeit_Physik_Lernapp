Physik Lernapp 1.0 – Android-Demo

ZIP entpacken und Physik-Lernapp-1.0.apk auf einem Android-Gerät öffnen.
Mindestversion: Android 5.0 (API 21). Zielversion: Android 13 (API 33).
Dies ist eine Demo mit Android-Debug-Signatur, keine Play-Store-Veröffentlichung.
Die App wurde im Android-13-Emulator mit 1080 x 2400 Pixeln ausprobiert.
Die feste Oberfläche kann auf kürzeren Displays Inhalte abschneiden.

Enthalten sind das Magnetismuskapitel, sechs Lernabschnitte, Formeln und acht leichte Aufgaben.
Weitere Themen und die Schaltflächen Mittel/Schwer sind Menüeinträge ohne eigene Aufgaben.
Die Fortschrittsanzeige übernimmt die originale Skala von zehn Aufgaben.
Alle Angaben und Downloads ohne Gewähr.

Programmquellen und Build-Konfiguration sind unverändert.
Der Ordner quellen enthält den App-Quellstand sowie das vollständige upstream-Quellarchiv
der drei JLaTeXMath-Module 0.2.0 mit Lizenz- und Schriftdateien.
JLaTeXMath steht unter GPLv2 oder später mit der im jeweiligen Lizenztext beschriebenen
Linking-Ausnahme. Die griechischen Schriften stehen unter GPLv2.
AndroidX, Material, Kotlin, Coroutines, JetBrains-Anmerkungen und Guava verwenden Apache 2.0.
Die jeweiligen Texte und vorhandenen Hinweise liegen unter lizenzen.
Das Paket vergibt keine neue pauschale Lizenz für den ursprünglichen App-Code oder seine Medien.

Quellen und Bedienung: https://github.com/Kennatris/Seminararbeit_Physik_Lernapp
Bibliothek v0.2.0: https://github.com/noties/jlatexmath-android/tree/v0.2.0
Rebuild: JDK 17, Gradle 8.0, Android SDK Platform 33 und Build Tools 30.0.3.
Im App-Quellordner: gradle testDebugUnitTest assembleDebug
SDK- und lokale Pfadkonfiguration gehören nicht in den Quelltext.
